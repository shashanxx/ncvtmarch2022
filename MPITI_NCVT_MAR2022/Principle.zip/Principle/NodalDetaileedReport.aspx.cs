﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common.Class;
using System.Data;
using System.Net;
using System.IO;
using System.Threading;
using System.Data.SqlClient;


public partial class Center_Joindirector : System.Web.UI.Page
{
    ClsErrorLog errlog = new ClsErrorLog();
    CommonPerception MySql = new CommonPerception();
    DataSet ds = new DataSet();
    string tradetype1 = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] == null)
        {
            Response.Redirect("../Login/LoginNew.aspx");
        }
        if (!IsPostBack)
        {
            lblUName.Text = "Welcome " + Convert.ToString(Session["Username"]);
            DataTable dt = new DataTable();
            dt = MySql.GetDataTableWithQuery("select * from  tbl_User_Profile where Name='" + Session["Username"].ToString() + "'");
            HiddenField2.Value = Session["Username"].ToString();
            BindDistrict();
            BindNameOfITI("0");
            BindTradeName();
        }
    }

    protected void BindDistrict()
    {
        DataTable dtDistrict = new DataTable();
        dtDistrict = MySql.GetDataTableWithQuery("select distinct ts.ExistsDistrict,lower(ts.ExistsDistrict) as 'LcaseDistrict' from tbl_Student ts where ts.ITICode in (select a.UserName from tbl_user a where a.SuperITIID=(select UserId from tbl_user b where b.UserName='" + Session["Username"].ToString() + "')) and ts.ExistsDistrict is not null order by ts.ExistsDistrict");
        if (dtDistrict != null && dtDistrict.Rows.Count > 0)
        {
            ddldistrict.DataSource = dtDistrict;
            ddldistrict.DataTextField = "ExistsDistrict";
            ddldistrict.DataValueField = "LcaseDistrict";
            ddldistrict.DataBind();
        }
        ddldistrict.Items.Insert(0, new ListItem("Select District", "0"));
    }

    protected void BindNameOfITI(string District)
    {
        ddlNameofITI.Items.Clear();
        DataTable dtITICodeName = new DataTable();
        if (District != "0")
            dtITICodeName = MySql.GetDataTableWithQuery("select distinct ts.ITIName,ts.ITICode from tbl_Student ts where ts.ITICode in (select a.UserName from tbl_user a where a.SuperITIID=(select UserId from tbl_user b where b.UserName='" + Session["Username"].ToString() + "') and ts.ExistsDistrict='" + District + "') and ts.ITICode is not null and ts.ITIName is not null  order by ts.ITIName");
        else
            dtITICodeName = MySql.GetDataTableWithQuery("select distinct ts.ITIName,ts.ITICode from tbl_Student ts where ts.ITICode in (select a.UserName from tbl_user a where a.SuperITIID=(select UserId from tbl_user b where b.UserName='" + Session["Username"].ToString() + "')) and ts.ITICode is not null and ts.ITIName is not null  order by ts.ITIName");
        if (dtITICodeName != null && dtITICodeName.Rows.Count > 0)
        {
            ddlNameofITI.DataSource = dtITICodeName;
            ddlNameofITI.DataTextField = "ITIName";
            ddlNameofITI.DataValueField = "ITICode";
            ddlNameofITI.DataBind();
        }
        ddlNameofITI.Items.Insert(0, new ListItem("Select", "0"));
    }

    protected void BindTradeName()
    {
        DataTable dtTrade = new DataTable();
        if (ddldistrict.SelectedValue != "0" && ddlNameofITI.SelectedValue != "0")
            dtTrade = MySql.GetDataTableWithQuery("select distinct tm.Tradeid,tm.TradeName from tbl_Student ts inner join TradeMaster tm on lower(ts.Trade)=lower(tm.TradeName) where ts.ITICode in (select a.UserName from tbl_user a where a.SuperITIID=(select UserId from tbl_user b where b.UserName='" + Session["Username"].ToString() + "') and ts.ExistsDistrict='" + ddldistrict.SelectedValue + "' and ts.ITICode='" + ddlNameofITI.SelectedValue + "') and TradeName not in ('Stenographer & Secretarial Assistant (English)','Stenographer & Secretarial Assistant (Hindi)','Secretarial Practice (English)') order by tm.TradeName");
        else if (ddldistrict.SelectedValue != "0")
            dtTrade = MySql.GetDataTableWithQuery("select distinct tm.Tradeid,tm.TradeName from tbl_Student ts inner join TradeMaster tm on lower(ts.Trade)=lower(tm.TradeName) where ts.ITICode in (select a.UserName from tbl_user a where a.SuperITIID=(select UserId from tbl_user b where b.UserName='" + Session["Username"].ToString() + "') and ts.ExistsDistrict='" + ddldistrict.SelectedValue + "') and TradeName not in ('Stenographer & Secretarial Assistant (English)','Stenographer & Secretarial Assistant (Hindi)','Secretarial Practice (English)') order by tm.TradeName");
        else if(ddlNameofITI.SelectedValue!="0")
            dtTrade = MySql.GetDataTableWithQuery("select distinct tm.Tradeid,tm.TradeName from tbl_Student ts inner join TradeMaster tm on lower(ts.Trade)=lower(tm.TradeName) where ts.ITICode in (select a.UserName from tbl_user a where a.SuperITIID=(select UserId from tbl_user b where b.UserName='" + Session["Username"].ToString() + "') and ts.ITICode='" + ddlNameofITI.SelectedValue + "') and TradeName not in ('Stenographer & Secretarial Assistant (English)','Stenographer & Secretarial Assistant (Hindi)','Secretarial Practice (English)') order by tm.TradeName");
        else
            dtTrade = MySql.GetDataTableWithQuery("select distinct tm.Tradeid,tm.TradeName from tbl_Student ts inner join TradeMaster tm on lower(ts.Trade)=lower(tm.TradeName) where ts.ITICode in (select a.UserName from tbl_user a where a.SuperITIID=(select UserId from tbl_user b where b.UserName='" + Session["Username"].ToString() + "')) and TradeName not in ('Stenographer & Secretarial Assistant (English)','Stenographer & Secretarial Assistant (Hindi)','Secretarial Practice (English)') order by tm.TradeName");
        if (dtTrade != null && dtTrade.Rows.Count > 0)
        {
            ddlTradeName.DataSource = dtTrade;
            ddlTradeName.DataTextField = "TradeName";
            ddlTradeName.DataValueField = "Tradeid";
            ddlTradeName.DataBind();
        }
        ddlTradeName.Items.Insert(0, new ListItem("Select", "0"));        
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            lblCMessage.Text = "";
            if (isvalidate())
            {
                FillGrid();
            }
        }
        catch (Exception ex)
        {
            errlog.LogError(ex);
        }
    }

    bool isvalidate()
    {
        //if (ddlentrytype.SelectedValue == "0")
        //{
        //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Notify", "alert('Please Select Entry Type');", true);
        //    ddlentrytype.Focus();
        //    return false;
        //}
        return true;
    }

    protected void btnExportToExcel_Click(object sender, EventArgs e)
    {
        try
        {
            if (isvalidate())
            {
                ExportToExcel();
            }
        }
        catch (Exception ex)
        {
            errlog.LogError(ex);
        }
    }

    public void ExportToExcel()
    {
        DataSet Ds = new DataSet();
        Ds = MySql.GetDataSetWithQuery("Exec getDetailedNodalReports @AdmissionYear=" + ddlAdmissionYear.SelectedValue + ",@Semester=" + ddlSemester.SelectedValue + ", @ExamType='" + ddlexamtype.SelectedValue + "', @Trade=" + ddlTradeName.SelectedValue + ",@ITICode='" + ddlNameofITI.SelectedValue + "', @District='" + ddldistrict.SelectedValue + "', @EntryType='" + ddlentrytype.SelectedValue + "'");
        if (Ds.Tables[0].Rows.Count > 0)
        {
            DataTable dtCloned = Ds.Tables[0];
            string filename = "	NodalDetailedReport";
            string attachment = "attachment; filename=" + filename + ".xls";
            Response.ClearContent();
            Response.AddHeader("content-disposition", attachment);
            Response.ContentType = "application/excel";
            StringWriter stw = new StringWriter();
            HtmlTextWriter htextw = new HtmlTextWriter(stw);
            GridView dgGrid = new GridView();
            dgGrid.DataSource = dtCloned;
            dgGrid.DataBind();
            dgGrid.RenderControl(htextw);
            Response.Write(stw.ToString());
            Response.End();
        }
    }

    void FillGrid()
    {
        DataSet Ds = new DataSet();
        Ds = MySql.GetDataSetWithQuery("Exec getDetailedNodalReports @AdmissionYear=" + ddlAdmissionYear.SelectedValue + ",@Semester=" + ddlSemester.SelectedValue + ", @ExamType='" + ddlexamtype.SelectedValue + "', @Trade=" + ddlTradeName.SelectedValue + ",@ITICode='" + ddlNameofITI.SelectedValue + "', @District='" + ddldistrict.SelectedValue + "', @EntryType='" + ddlentrytype.SelectedValue + "'");
        if (Ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = Ds;
            GridView1.DataBind();
            btnExportToExcel.Visible = true;
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
            lblCMessage.Text = "No data found";
        }
    }    

    protected void btnExit_Click(object sender, EventArgs e)
    {
        try
        {
            Session.Abandon();
            Response.Redirect("../Login/LoginNew.aspx");
        }
        catch (Exception ex)
        {
            errlog.LogError(ex);
        }
    }

    protected void ddldistrict_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindNameOfITI(ddldistrict.SelectedValue);
    }

    protected void ddlNameofITI_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindTradeName();
    }    

    protected void lnklogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("../Login/LoginNew.aspx");
    }
}